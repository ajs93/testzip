#!/bin/sh
#
# Post-update script
#
# This script will be executed after completing all the file renaming
# corresponding to the last update
#

printf "Post-update script started.\n"

# Real work here
printf "We should try a dd to overwrite some partition and check that nothing breaks.\n"

printf "Post-update script finished.\n"